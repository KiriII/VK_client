package com.renewalstudio.vk_client.Models;

public class FriendModel {
    String name;
    String surname;
    String image;
    boolean isOnline;

    public FriendModel(String name, String surname, String image, boolean isOnline){
        this.name = name;
        this.surname = surname;
        this.image = image;
        this.isOnline = isOnline;
    }
}
