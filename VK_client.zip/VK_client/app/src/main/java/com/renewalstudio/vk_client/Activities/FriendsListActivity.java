package com.renewalstudio.vk_client.Activities;

import androidx.appcompat.app.AlertController;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListAdapter;
import android.widget.ListView;

import com.renewalstudio.vk_client.R;

public class FriendsListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friends_list);

        ListView friendsList = (ListView)findViewById(R.id.friendList);
        RecycleView listAdapter = new Lis
    }
}
